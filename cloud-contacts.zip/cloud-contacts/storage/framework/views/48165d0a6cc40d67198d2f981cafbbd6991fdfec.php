<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
        <div class="content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="">
                        <h3 class="mb-3 font-weight-semibold site_heading">
                        <?php if(isset($contact)): ?>
                            Update Contact
                        <?php else: ?>
                            Add Contact
                        <?php endif; ?>   
                            <span id="case_type_title"></span>
                        </h3>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="row mb-4">
                
                    <?php if(isset($contact)): ?>
                        <?php echo e(Form::model($contact, ['route' => ['contacts.update', $contact->id], 'method' => 'patch', 'data-parsley-validate'])); ?>

                    <?php else: ?>
                        <?php echo Form::open(['method' => 'POST', 'route' => ['contacts.store'], 'data-parsley-validate']); ?>

                    <?php endif; ?>
                    <div class="col-lg-12 mt-5 ml-3">
                        <div class="row mr-5">
                            <div class="col-md-8">
                                <?php echo Form::label('last_name', 'First Name *', ['class' => 'control-label']); ?>

                                <div class="form-group">
                                    <?php echo Form::text('first_name', old('first_name'), ['class' => 'form-control', 'required' => '','data-parsley-maxlength'=>20]); ?>

                                    <p class="help-block"></p>
                                    <?php if($errors->has('first_name')): ?>
                                        <p class="help-block">
                                            <?php echo e($errors->first('first_name')); ?>

                                        </p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <?php echo Form::label('last_name', 'Last Name *', ['class' => 'control-label']); ?>

                                <div class="form-group">
                                    <?php echo Form::text('last_name', old('last_name'), ['class' => 'form-control', 'required' => '','data-parsley-maxlength'=>20]); ?>

                                    <p class="help-block"></p>
                                    <?php if($errors->has('last_name')): ?>
                                        <p class="help-block">
                                            <?php echo e($errors->first('last_name')); ?>

                                        </p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <?php echo Form::label('email', 'Email *', ['class' => 'control-label']); ?>

                                <div class="form-group">
                                    <?php echo Form::text('email', old('email'), ['class' => 'form-control', 'required' => '','data-parsley-maxlength'=>50]); ?>

                                    <p class="help-block"></p>
                                    <?php if($errors->has('email')): ?>
                                        <p class="help-block text-danger">
                                            <?php echo e($errors->first('email')); ?>

                                        </p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <?php echo Form::label('phone', 'Mobile No *', ['class' => 'control-label']); ?>

                                <div class="form-group">
                                    <?php echo Form::text('phone', old('phone'), ['class' => 'form-control', 'required' => '','data-parsley-maxlength'=>15]); ?>

                                    <p class="help-block"></p>
                                    <?php if($errors->has('phone')): ?>
                                        <p class="help-block text-danger">
                                            <?php echo e($errors->first('phone')); ?>

                                        </p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <?php echo Form::label('address', 'Address *', ['class' => 'control-label']); ?>

                                <div class="form-group">
                                    <?php echo Form::text('address', old('address'), ['class' => 'form-control', 'required' => '','data-parsley-maxlength'=>200]); ?>

                                    <p class="help-block"></p>
                                    <?php if($errors->has('address')): ?>
                                        <p class="help-block">
                                            <?php echo e($errors->first('address')); ?>

                                        </p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <?php echo Form::label('nick_name', 'Nick Name *', ['class' => 'control-label']); ?>

                                <div class="form-group">
                                    <?php echo Form::text('nick_name', old('nick_name'), ['class' => 'form-control', 'required' => '','data-parsley-maxlength'=>20]); ?>

                                    <p class="help-block"></p>
                                    <?php if($errors->has('nick_name')): ?>
                                        <p class="help-block">
                                            <?php echo e($errors->first('nick_name')); ?>

                                        </p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <?php echo Form::label('company', 'Company Name *', ['class' => 'control-label']); ?>

                                <div class="form-group">
                                    <?php echo Form::text('company', old('company'), ['class' => 'form-control', 'required' => '','data-parsley-maxlength'=>50]); ?>

                                    <p class="help-block"></p>
                                    <?php if($errors->has('company')): ?>
                                        <p class="help-block">
                                            <?php echo e($errors->first('company')); ?>

                                        </p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-8">
                            <div class="form-group">
                            <label>Status *</label>
                                <select name="status" id="status" class="form-control" >
                                    <option value="">-- Select --</option>
                                    <option value="1" <?php if(!empty($contact->status) && $contact->status=="1"): ?> selected="selected" <?php endif; ?>>Active</option>
                                    <option value="0" <?php if(isset($contact->status) && $contact->status=="0"): ?> selected="selected" <?php endif; ?>>Inactive</option>
                                </select></div>
                            </div>
                            <div class="col-md-12">
                            <?php if(isset($contact)): ?>
                                <?php echo Form::submit('Update', ['class' => 'btn btn-primary']); ?>

                                <a href="<?php echo e(route('contacts.index')); ?>">
                                    <?php echo Form::button(trans('Cancel'), ['class' => 'btn btn-primary']); ?>

                                </a>
                            <?php else: ?>
                                <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

                                <a href="<?php echo e(route('contacts.index')); ?>">
                                    <?php echo Form::button(trans('Cancel'), ['class' => 'btn btn-primary']); ?>

                                </a>
                            <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/cloud-contacts/resources/views/contacts/create.blade.php ENDPATH**/ ?>
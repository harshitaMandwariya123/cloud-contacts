<?php echo e($slot); ?>

<?php /**PATH /var/www/html/laravel-project/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>
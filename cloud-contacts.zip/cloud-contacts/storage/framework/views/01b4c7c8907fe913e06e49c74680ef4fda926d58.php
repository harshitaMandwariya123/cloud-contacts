<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Contacts</title>

        <!-- Global stylesheets -->
        <link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
        <link href="https://fonts.googleapis.com/css?family=Titillium+Web:300,400,600,700" rel="stylesheet">
        <link href="<?php echo e(url('css/icomoon/styles.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(url('css/fontawesome/styles.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(url('css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(url('css/bootstrap_limitless.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(url('css/layout.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(url('css/components.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(url('css/colors.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(url('css/vecv_fonts/style.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(url('css/site.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(url('css/toastr.min.css')); ?>" rel="stylesheet">
        <!-- /global stylesheets -->

        <!-- Core JS files -->
        <script src="<?php echo e(url('js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(url('js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(url('js/blockui.min.js')); ?>"></script>
        <!-- /core JS files -->

        <!-- Theme JS files -->
        <script src="<?php echo e(url('js/app_theme.js')); ?>"></script>
        <script src="<?php echo e(url('js/app.js')); ?>"></script>
        <script src="<?php echo e(url('js/custom.js')); ?>"></script>
        <script src="<?php echo e(url('js/plugins/d3/d3.min.js')); ?>"></script>
        <script src="<?php echo e(url('js/plugins/c3/c3.min.js')); ?>"></script>
        <script src="<?php echo e(url('js/plugins/jquery_ui/widgets.min.js')); ?>"></script>
        <script src="<?php echo e(url('js/plugins/forms/selects/select2.min.js')); ?>"></script>
        <!-- /theme JS files -->
        <!-- Demo JS Files-->
        <script src="<?php echo e(url('js/demo_js/c3_bars_pies.js')); ?>"></script>
        <script src="<?php echo e(url('js/demo_js/jqueryui_forms.js')); ?>"></script>
        <script src="<?php echo e(url('js/demo_js/timelines.js')); ?>"></script>
        <script src="<?php echo e(url('js/demo_js/form_select2.js')); ?>"></script>
        <script src="<?php echo e(url('js/demo_js/components_collapsible.js')); ?>"></script>
        <script src="<?php echo e(url('js/toastr.min.js')); ?>"></script>
        <script src="<?php echo e(url('js/parsley.js')); ?>"></script>
        <!-- /Demo JS Files-->
        <style type="text/css">
            

        </style>
    </head>

    <body class="sidebar-xs login_banner">
       

        <!-- Page content -->
        <div class="page-content pt-0">
          
            <div class="content-wrapper">
                <div class="content d-flex justify-content-center align-items-center">
                    <!-- Login card -->
                    <form class="login-form" method="POST" action="<?php echo e(route('register')); ?>" id="frm_user_login">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <div class="card mb-0 login_card">
                            <div class="">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="eicher_login">
                                            <div class="eicher_box-2">
                                                <img src="<?php echo e(url('images/contact.png')); ?>" alt="">
                                            </div>
                                            <div class="eicher_box-1">
                                                <div class="">
                                                    <div class="card-body">
                                                        <div class="form-width" style="">
                                                            <div class="text-center mb-3">
                                                                <h2 class="mb-0 ">Register</h5>
                                                            </div>

                                                          <div class="form-group form-group-feedback form-group-feedback-left <?php echo e($errors->has('first_name') ? ' has-error' : ''); ?>">
                                                                <input type="text" class="form-control" name="first_name" value="<?php echo e(old('first_name')); ?>" required autofocus data-parsley-required-message="Please enter first_name" placeholder="First Name" />
                                                                <div class="form-control-feedback">
                                                                    <i class="icon-user text-muted"></i>
                                                                </div>
                                                                <?php if($errors->has('first_name')): ?>
                                                                    <span class="help-block">
                                                                    <strong><?php echo e($errors->first('first_name')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>

                                                            <div class="form-group form-group-feedback form-group-feedback-left <?php echo e($errors->has('last_name') ? ' has-error' : ''); ?>">
                                                                <input type="text" class="form-control" name="last_name" value="<?php echo e(old('last_name')); ?>" required autofocus data-parsley-required-message="Please enter last_name" placeholder="Last Name" />
                                                                <div class="form-control-feedback">
                                                                    <i class="icon-user text-muted"></i>
                                                                </div>
                                                                <?php if($errors->has('last_name')): ?>
                                                                    <span class="help-block">
                                                                    <strong><?php echo e($errors->first('last_name')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>

                                                            <div class="form-group form-group-feedback form-group-feedback-left <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                                                <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus data-parsley-required-message="Please enter email" placeholder="email" />
                                                                <div class="form-control-feedback">
                                                                    <i class="icon-user text-muted"></i>
                                                                </div>
                                                                <?php if($errors->has('email')): ?>
                                                                    <span class="help-block">
                                                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>

                                                            <div class="form-group form-group-feedback form-group-feedback-left <?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
                                                                <input type="text" class="form-control" name="phone" value="<?php echo e(old('phone')); ?>" required autofocus data-parsley-required-message="Please enter phone" placeholder="phone" />
                                                                <div class="form-control-feedback">
                                                                    <i class="icon-user text-muted"></i>
                                                                </div>
                                                                <?php if($errors->has('phone')): ?>
                                                                    <span class="help-block">
                                                                    <strong><?php echo e($errors->first('phone')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>


                                                            <div class="form-group form-group-feedback form-group-feedback-left <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                                                <input id="password" type="password" class="form-control" name="password" required data-parsley-required-message="<?php echo e('Please enter password'); ?>" placeholder="Password" />
                                                                <div class="form-control-feedback">
                                                                    <i class="icon-lock2 text-muted"></i>
                                                                </div>
                                                                <?php if($errors->has('password')): ?>
                                                                    <span class="help-block">
                                                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                            <div class="form-group form-group-feedback form-group-feedback-left <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                                                <input id="password_confirmation" type="password" class="form-control" name="password_confirmation" required data-parsley-required-message="<?php echo e('Please enter password_confirmation'); ?>" placeholder="Password Confirmation" />
                                                                <div class="form-control-feedback">
                                                                    <i class="icon-lock2 text-muted"></i>
                                                                </div>
                                                                <?php if($errors->has('password_confirmation')): ?>
                                                                    <span class="help-block">
                                                                    <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                            <div class="form-group mb-1">
                                                                <button type="submit" class="btn btn-primary btn-block">Sign Up <i class="icon-circle-right2 ml-2"></i></button>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <a class="btn btn-link pl-0" href="<?php echo e(route('password.request')); ?>">
                                                                        Forgot Your Password?
                                                                    </a>
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <a  class="btn btn-link pl-0" href="/login">Login</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                    </form>
                    <!-- /login card -->
                </div>
            </div>
        
        </div>
        <!-- /page content -->
        <!-- Footer -->
        
        <div id="overlay" style="display:none;">
            <div class="spinner"></div>
            <br/>
            Loading...
        </div>
        <!-- /Footer -->
        <script type="text/javascript">
            $(document).ready(function(){
                toastr.options = {
                    "timeOut": 10000
                }

                <?php if(Session::has('success')): ?>
                    var msg = "<?php echo e(Session::get('success')); ?>";
                    toastr.success(msg, 'Success');
                <?php endif; ?>

                <?php if(Session::has('failure')): ?>
                    var msg = "<?php echo e(Session::get('failure')); ?>";
                    toastr.error(msg, 'Failed');
                <?php endif; ?>

                <?php if(Session::has('errors')): ?>
                    var validationError = '<?php echo e(config('app.messages.form_errors')); ?>';
                    toastr.error(validationError, 'Failed');
                <?php endif; ?>
            });
        </script>
        <script type="text/javascript">
            $(document).ready(function(){
                $("#frm_user_login").parsley();
            })
        </script>
        <?php echo $__env->yieldContent('scripts'); ?>
    </body>
</html>
<?php /**PATH /var/www/html/laravel-project/resources/views/auth/register.blade.php ENDPATH**/ ?>
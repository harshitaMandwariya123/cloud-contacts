<!-- Admin Case Management Header -->
<div class="d-xs-none">
    <div class="navbar navbar-expand-md navbar-dark">
        <!--Side Navigation Hide Show End-->
        <div class="collapse navbar-collapse" id="navbar-mobile">
            <ul class="navbar-nav ml-md-auto">
                <?php if(!empty(Auth::user())): ?>
                <li class="nav-item dropdown dropdown-user">
                    <a href="#" class="navbar-nav-link d-flex align-items-center dropdown-toggle" data-toggle="dropdown"><span><?php echo e(Auth::user()->name); ?></span></a>
                    <div class="dropdown-menu dropdown-menu-right">
                        <a href="<?php echo e(route('logout')); ?>" class="dropdown-item" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="icon-switch2"></i> Logout</a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo e(csrf_field()); ?>

                        </form>
                    </div>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</div>
<!-- /main navbar --><?php /**PATH /var/www/html/cloud-contacts/resources/views/layouts/header.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Contacts</title>

        <!-- Global stylesheets -->
        <link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
        <link href="https://fonts.googleapis.com/css?family=Titillium+Web:300,400,600,700" rel="stylesheet">
        <link href="<?php echo e(url('css/icomoon/styles.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(url('css/fontawesome/styles.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(url('css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(url('css/bootstrap_limitless.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(url('css/layout.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(url('css/components.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(url('css/colors.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(url('css/vecv_fonts/style.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(url('css/site.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(url('css/toastr.min.css')); ?>" rel="stylesheet">
        <!-- /global stylesheets -->

        <!-- Core JS files -->
        <script src="<?php echo e(url('js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(url('js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(url('js/blockui.min.js')); ?>"></script>
        <!-- /core JS files -->

        <!-- Theme JS files -->
        <script src="<?php echo e(url('js/app_theme.js')); ?>"></script>
        <script src="<?php echo e(url('js/app.js')); ?>"></script>
        <script src="<?php echo e(url('js/custom.js')); ?>"></script>
        <script src="<?php echo e(url('js/plugins/d3/d3.min.js')); ?>"></script>
        <script src="<?php echo e(url('js/plugins/c3/c3.min.js')); ?>"></script>
        <script src="<?php echo e(url('js/plugins/jquery_ui/widgets.min.js')); ?>"></script>
        <script src="<?php echo e(url('js/plugins/forms/selects/select2.min.js')); ?>"></script>
        <!-- /theme JS files -->
        <!-- Demo JS Files-->
        <script src="<?php echo e(url('js/demo_js/c3_bars_pies.js')); ?>"></script>
        <script src="<?php echo e(url('js/demo_js/jqueryui_forms.js')); ?>"></script>
        <script src="<?php echo e(url('js/demo_js/timelines.js')); ?>"></script>
        <script src="<?php echo e(url('js/demo_js/form_select2.js')); ?>"></script>
        <script src="<?php echo e(url('js/demo_js/components_collapsible.js')); ?>"></script>
        <script src="<?php echo e(url('js/toastr.min.js')); ?>"></script>
        <script src="<?php echo e(url('js/parsley.js')); ?>"></script>
        <!-- /Demo JS Files-->
        <style type="text/css">
            

        </style>
    </head>
    <body class="sidebar-xs login_banner">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

        <!-- Footer -->
        
        <div id="overlay" style="display:none;">
            <div class="spinner"></div>
            <br/>
            Loading...
        </div>
        <!-- /Footer -->
        <script type="text/javascript">
            $(document).ready(function(){
                toastr.options = {
                    "timeOut": 10000
                }

                <?php if(Session::has('success')): ?>
                    var msg = "<?php echo e(Session::get('success')); ?>";
                    toastr.success(msg, 'Success');
                <?php endif; ?>

                <?php if(Session::has('failure')): ?>
                    var msg = "<?php echo e(Session::get('failure')); ?>";
                    toastr.error(msg, 'Failed');
                <?php endif; ?>

                <?php if(Session::has('errors')): ?>
                    var validationError = '<?php echo e(config('app.messages.form_errors')); ?>';
                    toastr.error(validationError, 'Failed');
                <?php endif; ?>
            });
        </script>
        <script type="text/javascript">
            $(document).ready(function(){
                $("#frm_user_login").parsley();
            })
        </script>
        <?php echo $__env->yieldContent('scripts'); ?>
    </body>
</html>

<?php /**PATH /var/www/html/cloud-contacts/resources/views/layouts/custom.blade.php ENDPATH**/ ?>